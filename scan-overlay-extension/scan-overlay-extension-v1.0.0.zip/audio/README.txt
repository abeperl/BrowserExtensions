// This is a placeholder for scan audio feedback files.
// Place the following files in this directory:
// - scan.mp3 (for scan event)
// - warning.mp3 (for pre-submit/amber)
// - success.mp3 (for green/success)
// - error.mp3 (for error overlays)
//
// You can use royalty-free notification sounds or generate your own.
