﻿# Word Template Extension Installer

This package contains everything needed to install and use the Word Template Extension.

## Installation Steps

1. **Run install.bat** - This will:
   - Check Python installation
   - Install required Python packages
   - Register the native messaging host
   - Create template directories

2. **Install Browser Extension**:
   - Open Chrome or Edge
   - Go to Extensions page (chrome://extensions/ or edge://extensions/)
   - Enable "Developer mode"
   - Click "Load unpacked" and select the extension folder
   - OR drag the ZIP file onto the extensions page

3. **Add Templates**:
   - Place Word templates in: Documents\Word Template Extension\Templates\
   - Use placeholders like {{EMAIL}}, {{PHONE}}, {{DATE}} in your templates

## System Requirements

- Windows 10/11
- Python 3.7+
- Microsoft Word
- Chrome or Edge browser

## Support

For help and documentation: https://github.com/your-repo/word-template-extension
